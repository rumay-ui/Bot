module.exports = {
  BOT_TOKEN: "TOKEN_BOT",
};